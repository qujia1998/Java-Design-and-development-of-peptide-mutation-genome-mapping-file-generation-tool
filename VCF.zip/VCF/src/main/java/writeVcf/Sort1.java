package writeVcf;

import readgff.ReadFile;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Sort1 {
    public static void Sort_wt1() throws Exception {
        ReadFile rgff = new ReadFile();
        List<String> sb1 = new ArrayList<>();
        sb1=rgff.Rdgff("E:/毕设/新建文件夹/result/result.vcf");
        for ( int i = 6 ; i < sb1.size()-1 ; i++){
            for ( int j =i+1 ; j < sb1.size() ; j++){
                if (Integer.parseInt(sb1.get(i).split("\t")[1]) > Integer.parseInt(sb1.get(j).split("\t")[1])){
                    List<String > sb2 = Arrays.asList(sb1.get(i));
                    for (int k =0 ; k < 8 ; k++){
                        sb1.get(i).split("\t")[k]=sb1.get(j).split("\t")[k];
                    }
                    for (int k =0 ; k < 8 ; k++){
                        sb1.get(j).split("\t")[k]=sb2.get(0).split("\t")[k];
                    }

                }
                else continue;
            }
        }

        System.out.println(sb1);
        ReadFile.write(sb1,"E:/毕设/新建文件夹/result/result_1.vcf");
    }
}
