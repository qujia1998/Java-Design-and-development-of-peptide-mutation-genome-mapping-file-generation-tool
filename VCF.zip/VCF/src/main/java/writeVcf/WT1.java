package writeVcf;

import meta.fileFormat;
import meta.filter.Filter;
import meta.format.Format;
import meta.info.Info;

import java.io.*;
import java.util.List;

public class WT1 {
    public void writeTest1(List<Object> array) throws FileNotFoundException {
        File file = new File("E:/毕设/新建文件夹/result/result.vcf");

        //System.out.println(array.size());
        for(int i = 0;i<array.size();i++){
            FileOutputStream fos = new FileOutputStream(file,true);
            List<String> list1 = (List<String>) array.get(i);
            //System.out.println(list1.get(0));
            PrintStream out1 = new PrintStream(fos);
            String str= list1.get(0)+"\n";
            //System.out.println(str);
            out1.print(str);
            out1.flush();
            out1.close();
        }
    }

    public static void writeTest2(List<Object> arrayRecordTitle,List<Object> array) throws Exception {
        String Path="E:/毕设/新建文件夹/result/result.vcf";
        File file = new File(Path);
        //如果没有文件就创建
        if (!file.isFile()) {
            file.createNewFile();
        }
        BufferedWriter writer = new BufferedWriter(new FileWriter(Path));
        //写入meta
        fileFormat fileFormat = new fileFormat();
        List<Object> fileFormatList = fileFormat.getFileFormat();
        LoopListWrite(writer,fileFormatList);
        /*
        //INFO
        Info info = new Info();
        List<Object> infoList = info.getINFOTest();
        LoopListWrite(writer,infoList);
        //Filter
        Filter filter = new Filter();
        List<Object> filterList = filter.getFilter();
        LoopListWrite(writer,filterList);
        //Format
        Format format = new Format();
        List<Object> formatList = format.getFormat();
        LoopListWrite(writer,formatList);*/



        //写入列名
        LoopListWrite(writer,arrayRecordTitle);
        //写入记录
        LoopListWrite(writer,array);

        System.out.println("写入完毕");

        writer.flush();
        writer.close();
    }

    /**
     * 辅助函数  循环list 并将其类容写入到vcf
     * @param writer
     * @param array
     * @throws IOException
     */
    public static void LoopListWrite(BufferedWriter writer,List<Object> array) throws IOException {
        for(int i = 0;i<array.size();i++){
            List<String> list1 = (List<String>) array.get(i);
            //System.out.println(list1);
            for (String l:list1) {
                //System.out.println(l);
                writer.write(l + "\r\n");
            }
        }
    }

}
