package readgff;

import java.io.*;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ReadFile {
    //读取
    public static List<String> read(String Path) {
        try {
            StringBuffer sb = new StringBuffer("");
            FileReader reader = new FileReader(Path);
            BufferedReader br = new BufferedReader(reader);
            String str = null;

            //按行存入List
            List<String> lists = new ArrayList<>();
            while ((str = br.readLine()) != null) {
                sb.append(str + "/n");
                lists.add(str);
                //System.out.println(str);
            }
            br.close();
            reader.close();
            return lists;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    //写入
   public static void write(List<String> sb,String Path) throws IOException {
        FileWriter writer = new FileWriter(Path);
        BufferedWriter bw = new BufferedWriter(writer);
        for(int i=0;i<sb.size();i++){
            bw.write(sb.get(i));
            bw.write("\n");
        }
        //bw.write(sb.toString());
        bw.close();
        writer.close();
        System.out.println("写入完毕");
    }


    public static List<String> Rdgff(String Path) throws Exception {
        List<String> sb1 = new ArrayList<>();
        sb1 = read(Path);
        return sb1;
        /*for (int i = 2; i < sb1.size(); i++)
        {
            if(sb1.get(i).split("\t")[2].equals("Modified residue")){
                System.out.println(sb1.get(i).split("\t")[3]);
                System.out.println(sb1.get(i).split("\t")[8]);
            }

        }*/
        //System.out.println(sb1.get(8).split("\t")[2].equals("Modified residue"));
    }
}
