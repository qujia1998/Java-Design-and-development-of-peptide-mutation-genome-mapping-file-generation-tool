package entry;

import java.io.Serializable;

public class AltEntry implements Serializable {
    String Alt;

    public String getAlt() {

        return Alt;
    }

    public void setAlt(String alt) {

        Alt = alt;
    }
}
