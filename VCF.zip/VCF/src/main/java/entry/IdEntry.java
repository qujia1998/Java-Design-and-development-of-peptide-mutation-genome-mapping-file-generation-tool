package entry;

import java.io.Serializable;

public class IdEntry implements Serializable {
    String id = ".";

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
