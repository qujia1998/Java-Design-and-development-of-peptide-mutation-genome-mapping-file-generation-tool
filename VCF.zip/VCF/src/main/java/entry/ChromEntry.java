package entry;

import java.io.Serializable;

public class ChromEntry implements Serializable {
    String chrom;

    public String getChrom() {
        return chrom;
    }

    public void setChrom(String chrom) {
        this.chrom = chrom;
    }
}
