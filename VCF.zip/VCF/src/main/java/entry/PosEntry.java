package entry;

import java.io.Serializable;

public class PosEntry implements Serializable {
    int POS;

    public int getPOS() {
        return POS;
    }

    public void setPOS(int POS) {
        this.POS = POS;
    }
}
