package main;

import records.Chrom;
import records.Info;
import records.impl.ChromImpl;
import records.impl.InfoImpl;
import recordsMap.recordsMap1;
import writeVcf.WT1;
import writeVcf.Sort1;
import utils.ReadFile;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Main1 {
    public static void main(String[] args) throws Exception {
        System.out.println("JAVA - VCF");
        ReadFile.GetSeqandRSnum();
        recordsMap1 recordsMap1 = new recordsMap1();
        //顺序不能改变 因为Sample需要现在records中获得才能写入列名 sample的列名不是固定的 根据用户提供进行变化
        List<Object> arrayRecord = recordsMap1.getRecordMap();
        List<Object> arrayRecordTitle = recordsMap1.getRecordTitleMap();
        //写入测试
        WT1 wt1 = new WT1();
        //写入meta
        //写入记录
        wt1.writeTest2(arrayRecordTitle,arrayRecord);

    }
}
