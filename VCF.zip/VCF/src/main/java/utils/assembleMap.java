package utils;

import java.util.HashMap;
import java.util.Map;

public class assembleMap {
    public Map<Integer,Object> assemble(Integer index,String name,String value){
        Map<Integer,Object> map = new HashMap<Integer, Object>();
        Map<String,String> mapName = new HashMap<String, String>();
        mapName.put(name,value);
        map.put(index,mapName);
        return map;
    }
    public Map<Integer,Object> assemble(Integer index,String name,Integer value){
        Map<Integer,Object> map = new HashMap<Integer, Object>();
        Map<String,Integer> mapName = new HashMap<String, Integer>();
        mapName.put(name,value);
        map.put(index,mapName);
        return map;
    }

    public Map<String,String> assemble(String name,String value){
        Map<String,String> mapName = new HashMap<String, String>();
        mapName.put(name,value);
        return mapName;
    }
}
