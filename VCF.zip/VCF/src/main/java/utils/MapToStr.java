package utils;

import java.util.Arrays;
import java.util.Map;
import java.util.Set;

public class MapToStr {
    //参数类型是Map<String,String>
    /**
     *
     * map转str
     * @param map
     * @return
     */
    public String getMapToString(Map<String,String> map){
        Set<String> keySet = map.keySet();
        //将set集合转换为数组
        String[] keyArray = keySet.toArray(new String[keySet.size()]);
        //给数组排序(升序)
        //Arrays.sort(keyArray);
        //因为String拼接效率会很低的，所以转用StringBuilder。
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < keyArray.length; i++) {

                //System.out.println(keyArray[i]);
                //System.out.println(map.get(keyArray[i]));
                if (map.get(keyArray[i]) != null) {
                    sb.append(keyArray[i]).append("=").append(map.get(keyArray[i]).trim());
                }
                if (map.get(keyArray[i]) == null || map.get(keyArray[i]) == "null") {
                    sb.append(keyArray[i]);
                }
                if (i != keyArray.length - 1) {
                    sb.append(";");
                }

        }
        //System.out.println(sb);
        return sb.toString();
    }

}
