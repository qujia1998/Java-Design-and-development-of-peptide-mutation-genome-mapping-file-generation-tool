package utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.concurrent.TimeUnit;

public class apihgvs{
    //Test
    public static String testJsonResult(int rsnum) throws IOException {
        //System.out.println("https://api.ncbi.nlm.nih.gov/variation/v0/beta/refsnp/"+rsnum);
        URL connect = isConnect("https://api.ncbi.nlm.nih.gov/variation/v0/beta/refsnp/"+rsnum);
        if (null != connect){
            return loadJson(connect.toString());
        }
        else {
            return null;
        }
    }


    public static synchronized URL isConnect(String urlStr) {
        URL url = null;
        HttpURLConnection connection = null;
        int counts = 0;
        if (urlStr == null || urlStr.length() <= 0) {
            return null;
        }
        while (counts < 5) {
            try {
                url = new URL(urlStr);
                connection = (HttpURLConnection) url.openConnection();
                int code = connection.getResponseCode();
                //System.out.println(counts +" = "+code);
                if (code == 200) {
                    //System.out.println("URL可用！");
                }
                break;
            } catch (Exception ex) {
                counts++;
                //System.out.println("URL不可用，连接第 " + counts +"次");
                urlStr = null;
                continue;
            }
        }
        return url;
    }


    public static String loadJson(String url) {
        StringBuilder json = new StringBuilder();
        try {
            URL urlObject = new URL(url);
            URLConnection uc = urlObject.openConnection();
            // 设置为utf-8的编码 才不会中文乱码
            BufferedReader in = new BufferedReader(new InputStreamReader(uc
                    .getInputStream(), "utf-8"));
            String inputLine = null;
            while ((inputLine = in.readLine()) != null) {
                json.append(inputLine);
            }
            in.close();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return json.toString();
    }


    public static String rsRearch(int rsnum) throws IOException, InterruptedException {
        TimeUnit.SECONDS.sleep(40);//秒

        String json1 = testJsonResult(rsnum);
        String json2 = null;

        for(int i = 0 ; i < json1.split(",").length ; i++) {
            if(json1.split(",|\\{|\\}|\\[|\\]")[i].equals("\"is_ptlp\":true")){
                json2 = json1.split(",|\\{|\\}|\\[|\\]")[i+38];
            }

        }

        return json2;
    }


}
