package utils;


import java.io.*;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ReadFile {
    //读取
    public static List<String> read(String Path) {
        try {
            StringBuffer sb = new StringBuffer("");
            FileReader reader = new FileReader(Path);
            BufferedReader br = new BufferedReader(reader);
            String str = null;

            //按行存入List
            List<String> lists = new ArrayList<>();
            while ((str = br.readLine()) != null) {
                sb.append(str + "/n");
                lists.add(str);
                //System.out.println(str);
            }
            br.close();
            reader.close();
            return lists;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    //写入
    public static void write(List<String> sb,String Path) throws IOException {
        FileWriter writer = new FileWriter(Path);
        BufferedWriter bw = new BufferedWriter(writer);
        for(int i=0;i<sb.size();i++){
            bw.write(sb.get(i));
            bw.write("\n");
        }
        //bw.write(sb.toString());
        bw.close();
        writer.close();
        System.out.println("写入完毕");
    }


    public static void GetSeqandRSnum() throws IOException, InterruptedException {
        List<String> rs = new ArrayList<>();
        List<String> result = new ArrayList<>();
        List<String> sb1 = new ArrayList<>();
        TreeSet hs = new TreeSet();
        sb1 = read("E:/毕设/new/流程&数据/control_exo_rep2_med_mol_weight.dat-pride.pride.mztab");
        String seq1 = null;
        int num1 = 0, num2 = 0;
        for (int i = 0; i < sb1.size(); i++) {
            if (i == 0) {
                //避免i=0时报错
                seq1 = sb1.get(i).split("\t")[1];
                SearchString(seq1, hs);
                continue;
            }
            if (sb1.get(i).split("\t")[0].equals("PSM")) {

                if (sb1.get(i - 1).split("\t")[1].equals(sb1.get(i).split("\t")[1])) {
                    i++;
                    continue;
                }
                System.out.print(sb1.get(i).split("\t")[1] + "\n");
                seq1 = sb1.get(i).split("\t")[1];
                SearchString(seq1, hs);

            }


        }
        Iterator it = hs.iterator();
        while (it.hasNext()) {
            Object next = it.next();
            rs.add(next.toString());
        }
        System.out.println();
        write(rs,"E:/毕设/新建文件夹/re/seq_rs.docx");
        rs.clear();
        System.out.println("已完成seq和rs序列提取");
        System.out.println("开始链接网络返回json格式文件并处理");
        rs = read("E:/毕设/新建文件夹/re/seq_rs.docx");
        apihgvs hgvs = new apihgvs();
        for (int i = 0 ; i < rs.size() ; i++){
            String flag2 = NumberGet(rs.get(i).split("\t|=")[3]);
            int numb = Integer.parseInt(flag2);
            //System.out.println(flag2);
            String hgvsnum = hgvs.rsRearch(numb);
            if(hgvsnum == null ){
                continue;
            }
            result.add(rs.get(i).split("\t|=")[1]+"\t"+hgvsnum.replaceAll("\\\"",""));
            System.out.println(rs.get(i).split("\t|=")[1]+"\t"+hgvsnum);
        }
        write(result,"E:/毕设/新建文件夹/result/result.docx");
        System.out.println("已完成网络访问！");
    }

    public static void SearchString(String seq2, TreeSet hs) throws IOException, InterruptedException {
        List<String> sb2 = new ArrayList<>();
        int count = 0;
        sb2 = read("E:/毕设/new/流程&数据/Ensembl79_homo_dbSNP_variation_protein.txt");
        for (int i = 0; i < Objects.requireNonNull(sb2).size(); i++) {

            ThroughIndexOf(sb2.get(i).split("\t")[3], seq2, count, sb2.size(), sb2, hs);
            count++;
        }

    }


    //查找匹配


    public static void ThroughIndexOf(String parent, String child, int count, int i, List<String> sb2, TreeSet hs) throws IOException, InterruptedException {
        int StartIndex = 0;
        int data1[] = new int[i];
        apihgvs hgvs = new apihgvs();
        while (parent.indexOf(child, StartIndex) != -1) {
            StartIndex = parent.indexOf(child, StartIndex);
            StartIndex += child.length();
            data1[count] = StartIndex;
        }
        int j;
        for (j = 0; j < data1.length; j++) {
            if (data1[j] != 0) {
                for (int j1 = 3; j1 < sb2.get(j).split("\t|;|:|\n").length - 1; j1 += 2) {
                    String flag1 = NumberGet(sb2.get(j).split("\t|;|:|\n")[j1]);
                    int numa = Integer.parseInt(flag1);
                    if (numa >= data1[j] - child.length() && numa <= data1[j]) {
                        System.out.print(j + 1 + "\t");
                        System.out.print(data1[j] + "\t");
                        System.out.print(sb2.get(j).split("\t|;|:|\n")[j1 - 1] + "\t");
                        System.out.println(sb2.get(j).split("\t|;|:|\n")[j1]);
                        String flag2 = NumberGet(sb2.get(j).split("\t|;|:|\n")[j1 - 1]);
                        int numb = Integer.parseInt(flag2);
                        hs.add(new Person(child,numb,"test"));

                    }
                }
            }


        }


    }

    public static String NumberGet(String a) {
        String regEx = "[^0-9]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(a);
        return m.replaceAll("").trim();
    }
}

class Person implements Comparable {
    private String seq2;
    private int pronum;
    private String hgvsnum;
    public Person() {
    }
    public Person(String seq2, int pronum, String hgvsnum) {
        this.seq2 = seq2;
        this.pronum = pronum;
        this.hgvsnum = hgvsnum;
    }
    public String setSeq2() {
        return seq2;
    }
    public void setSeq2(String seq2) {
        this.seq2 = seq2;
    }
    public int getAge() {
        return pronum;
    }
    public void setAge(int pronum) {
        this.pronum = pronum;
    }
    public String getGender() {
        return hgvsnum;
    }
    public void setGender(String hgvsnum) {
        this.hgvsnum = hgvsnum;
    }
    @Override
    public int hashCode() {
        return seq2.hashCode() + pronum * 37;
    }
    public boolean equals(Object obj) {
        System.err.println(this + "equals :" + obj);
        if (!(obj instanceof Person)) {
            return false;
        }
        Person p = (Person) obj;
        return this.seq2.equals(p.seq2) && this.pronum == p.pronum;
    }
    public String toString() {
        return "seq2=" + seq2 +"\t"+ "rs="+pronum/*"hgvsnum=" + hgvsnum*/;

    }
    @Override
    public int compareTo(Object obj) {
        Person p = (Person) obj;
        //System.out.println(this+" compareTo:"+p);
        if (this.pronum > p.pronum) {
            return 1;
        }
        if (this.pronum < p.pronum) {
            return -1;
        }
        return this.seq2.compareTo(p.seq2);
    }
}
