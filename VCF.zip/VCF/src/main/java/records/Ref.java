package records;

import java.util.Map;

public interface Ref {
    Map<Integer,Object> getRefFromUser() throws Exception;
}
