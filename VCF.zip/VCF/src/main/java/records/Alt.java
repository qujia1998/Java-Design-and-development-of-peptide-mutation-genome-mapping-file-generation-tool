package records;

import java.util.Map;

public interface Alt {
    Map<Integer,Object> getAltFromUser() throws Exception;
}
