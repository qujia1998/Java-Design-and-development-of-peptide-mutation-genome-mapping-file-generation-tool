package records;

import java.util.Map;

public interface Pos {
    Map<Integer,Object> getPosFormUser() throws Exception;
}
