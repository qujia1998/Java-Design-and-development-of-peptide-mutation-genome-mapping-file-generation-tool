package records;

import java.util.Map;

public interface Info {
    Map<Integer,Object> getInfoFormUser();
}
