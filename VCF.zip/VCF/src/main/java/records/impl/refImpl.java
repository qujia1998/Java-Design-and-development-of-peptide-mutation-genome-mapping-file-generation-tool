package records.impl;

import entry.RefEntry;
import readgff.ReadFile;
import records.Ref;
import utils.assembleMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class refImpl implements Ref {
    private assembleMap assembleMap = new assembleMap();

//    public Map<Integer, Object> getRefFromUser() {
//        Map<Integer,Object> map = assembleMap.assemble(1,"ref","A");
//        return map;
//    }

    public Map<Integer, Object> getRefFromUser() throws Exception {
        Map<Integer,Object> map = new HashMap<Integer, Object>();
        ReadFile rgff = new ReadFile();
        List<String> sb1 = new ArrayList<>();
        sb1=rgff.Rdgff("E:/毕设/新建文件夹/result/result.docx");
        for(int i=0;i<sb1.size();i++){
            map.put(i,assembleMap.assemble("ref",NumberGet(sb1.get(i).split("\t|:|\\_|\\.|\\>")[6])));
        }
        return map;
    }
    public static String NumberGet(String a) {
        String regEx = "[^A-Z]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(a);
        return m.replaceAll("").trim();
    }
}
