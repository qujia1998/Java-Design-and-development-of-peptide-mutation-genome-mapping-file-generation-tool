package records.impl;
import readgff.ReadFile;
import records.Id;
import utils.assembleMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class IdImpl implements Id {
    private utils.assembleMap assembleMap = new assembleMap();

//    public Map<Integer, Object> getIdFormUser() {
//        Map<Integer,Object> map = assembleMap.assemble(1,"id","rs198777");
//        return map;
//    }
    public Map<Integer, Object> getIdFormUser() throws Exception {
        Map<Integer,Object> map = new HashMap<Integer, Object>();
        ReadFile rgff = new ReadFile();
        List<String> sb1 = new ArrayList<>();
        sb1=rgff.Rdgff("E:/毕设/新建文件夹/result/result.docx");
        for(int i=0;i<sb1.size();i++){
            map.put(i,assembleMap.assemble("id", sb1.get(i).split("\t")[0]));
        }
        return map;
    }
}
