package records.impl;

import entry.AltEntry;
import readgff.ReadFile;
import records.Alt;
import utils.assembleMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AltImpl implements Alt {
    private assembleMap assembleMap = new assembleMap();

//    public Map<Integer, Object> getAltFromUser() {
//        Map<Integer,Object> map = assembleMap.assemble(1,"alt","C");
//        return map;
//    }

    public Map<Integer, Object> getAltFromUser() throws Exception {
        Map<Integer,Object> map = new HashMap<Integer, Object>();
        ReadFile rgff = new ReadFile();
        List<String> sb1 = new ArrayList<>();
        sb1=rgff.Rdgff("E:/毕设/新建文件夹/result/result.docx");
        for(int i=0;i<sb1.size();i++){
            map.put(i,assembleMap.assemble("alt",sb1.get(i).split("\t|:|\\_|\\.|\\>")[sb1.get(i).split("\t|:|\\_|\\.|\\>").length-1]));
        }
        return map;
    }
}
