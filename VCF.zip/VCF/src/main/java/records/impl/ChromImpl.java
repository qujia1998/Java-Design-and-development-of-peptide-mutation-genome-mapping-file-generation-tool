package records.impl;
import readgff.ReadFile;
import entry.ChromEntry;
import records.Chrom;
import utils.assembleMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ChromImpl implements Chrom {
    private ChromEntry chromEntry = new ChromEntry();
    private assembleMap assembleMap = new assembleMap();

    /**
     * 组装map 并返回
     * @return
     */
    /*
    public Map<Integer, Object> getChromFromUser() {
        Map<Integer,Object> map = assembleMap.assemble(1,"name","X");
        return map;
    }

     */

    public Map<Integer, Object> getChromFromUser() throws Exception {
        Map<Integer,Object> map = new HashMap<Integer, Object>();
        ReadFile rgff = new ReadFile();
        List<String> sb1 = new ArrayList<>();
        sb1=rgff.Rdgff("E:/毕设/新建文件夹/result/result.docx");
        for(int i=0;i<sb1.size();i++){
            map.put(i,assembleMap.assemble("name", String.valueOf(Integer.parseInt(sb1.get(i).split("\t|:|\\_|\\.|\\>")[3]))));
        }
        return map;
    }
}
