package records.impl;

import records.Samples;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SamplesImpl implements Samples {
    public Map<Integer, Object> getSampleFromUser() {
        Map<Integer,Object> map1 = new HashMap<Integer, Object>();
        Map<String, List<String>> mapSample = getSample();
        map1.put(0,mapSample);
        map1.put(1,mapSample);
        map1.put(2,mapSample);
        //System.out.println("Sample:"+map1);
        return map1;
    }

    public Map<String, List<String>> getSample(){
        Map<String, List<String>> mapSample = new HashMap<String, List<String>>();
        List<String> listSample = new ArrayList<String>();
        List<String> listValue = new ArrayList<String>();
        /*listValue.add("0|0：48：1：51，51");
        listValue.add("1|0：48：8：51，51");
        listValue.add("2|0：48：4：51，51");*/
        mapSample.put("sample",listSample);
        mapSample.put("value",listValue);
        return mapSample;
    }
}
