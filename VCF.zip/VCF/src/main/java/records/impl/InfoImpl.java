package records.impl;

import records.Info;
import utils.assembleMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class InfoImpl implements Info {
    //private utils.assembleMap assembleMap = new assembleMap();
    public Map<Integer, Object> getInfoFormUser() {
        /*
        //初始化数据
        List<Object> listKey1 = new ArrayList<Object>();
        List<String> listKey2 = new ArrayList<String>();
        listKey2.add("NS");
        listKey2.add("DP");
        listKey2.add("AF");
        listKey1.add(listKey2);
        listKey2.add("NS");
        listKey2.add("AA");
        listKey1.add(listKey2);

        List<Object> listValue1 = new ArrayList<Object>();
        for(int i=0;i<2;i++) {
            List<String> listValue2 = new ArrayList<String>();
            listValue2.add("3");
            listValue2.add("14");
            listValue2.add("0.5");
            listValue1.add(listValue2);
        }
        System.out.println(listValue1);
         */

        Map<Integer,Object> map = new HashMap<Integer, Object>();
        /*Map<String,String> map1 = new HashMap<String, String>();
        Map<String,String> map2 = new HashMap<String, String>();
        Map<String,String> map3 = new HashMap<String, String>();
        map1.put("NS","3");
        map1.put("DP","14");
        map1.put("AF","0.5");
        map1.put("DB",null);
        map.put(0,map1);
        map2.put("NS","2");
        map2.put("DP","9");
        map2.put("AA","G");
        map.put(1,map2);
        map3.put("NS","2");
        map3.put("DP","9");
        map3.put("AA","G");
        map.put(2,map3);*/
        return map;
    }
}
