package records.impl;

import readgff.ReadFile;
import records.Format;
import records.Info;
import utils.assembleMap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FormatImpl implements Format {
    private utils.assembleMap assembleMap = new assembleMap();
    public Map<Integer, Object> getFormatFromUser() throws Exception {
        Map<Integer,Object> map = new HashMap<Integer, Object>();
        Map<String,String> mapFormat = new HashMap<String, String>();
        mapFormat.put("format",".");
        ReadFile rgff = new ReadFile();
        List<String> sb1 = new ArrayList<>();
        sb1=rgff.Rdgff("E:/毕设/新建文件夹/result/result.docx");
        for (int i =0; i<sb1.size();i++){
            map.put(i,mapFormat);
        }
        /*map.put(0,mapFormat);
        map.put(1,mapFormat);
        map.put(2,mapFormat);*/
        return map;
    }


    public Map<String,String> getFormat(){

        return null;
    }
}
