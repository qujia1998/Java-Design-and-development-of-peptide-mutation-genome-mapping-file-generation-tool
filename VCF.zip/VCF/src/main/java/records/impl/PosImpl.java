package records.impl;

import entry.PosEntry;
import records.Pos;
import utils.assembleMap;
import readgff.ReadFile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PosImpl implements Pos {
    private utils.assembleMap assembleMap = new assembleMap();
//    public Map<Integer, Object> getPosFormUser() {
////        Map<Integer,Object> map = assembleMap.assemble(1,"pos","12");
////        return map;
////    }

    public Map<Integer, Object> getPosFormUser() throws Exception {
        Map<Integer,Object> map = new HashMap<Integer, Object>();
        ReadFile rgff = new ReadFile();
        List<String> sb1 = new ArrayList<>();
        sb1=rgff.Rdgff("E:/毕设/新建文件夹/result/result.docx");
        for(int i=0;i<sb1.size();i++){
            map.put(i,assembleMap.assemble("pos", NumberGet(sb1.get(i).split("\t|:|\\_|\\.|\\>")[6])));
        }
        return map;
    }
    public static String NumberGet(String a) {
        String regEx = "[^0-9]";
        Pattern p = Pattern.compile(regEx);
        Matcher m = p.matcher(a);
        return m.replaceAll("").trim();
    }
}
