package records;

import java.util.Map;

public interface Samples {
    Map<Integer,Object> getSampleFromUser();
}
