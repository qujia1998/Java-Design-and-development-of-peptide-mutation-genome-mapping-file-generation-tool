package records;

import java.util.Map;

public interface Format {
    Map<Integer,Object> getFormatFromUser() throws Exception;
}
