package records;

import java.util.Map;

public interface Filter {
    Map<Integer,Object> getFilterFromUser() throws Exception;
}
