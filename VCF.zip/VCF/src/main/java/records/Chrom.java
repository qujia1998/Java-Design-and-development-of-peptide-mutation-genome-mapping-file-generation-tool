package records;

import java.util.Map;

public interface Chrom {
    /**
     * 返回一个包含染色体名称地map {1：{name:X}}
     * @return
     */
    Map<Integer,Object> getChromFromUser() throws Exception;
}
