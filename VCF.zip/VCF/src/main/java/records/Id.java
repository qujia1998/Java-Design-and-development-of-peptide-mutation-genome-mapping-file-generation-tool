package records;

import java.util.Map;

public interface Id {
    Map<Integer,Object> getIdFormUser() throws Exception;
}
