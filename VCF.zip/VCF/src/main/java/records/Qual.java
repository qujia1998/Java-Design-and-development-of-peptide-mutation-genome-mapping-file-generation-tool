package records;

import java.util.Map;

public interface Qual {
    Map<Integer,Object> getQualFromUser() throws Exception;
}
