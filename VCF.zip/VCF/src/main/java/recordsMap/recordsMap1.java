package recordsMap;

import records.*;
import records.impl.*;
import utils.MapToStr;

import java.util.*;

public class recordsMap1 {
    public String[] Samples;
    /**
     * records 列名 枚举
     */
    enum recordTitleEnum{
        CHROM("CHROM"),POS("POS"),ID("ID"),REF("REF"),ALT("ALT")/*,PTMs("PTMs")*/,QUAL("QUAL"),
        FILTER("FILTER"),INFO("INFO"),FORMAT("FORMAT");
        private String value;
        recordTitleEnum(String value) { this.value=value; }
        public String getValue() { return value; }
        public void setValue(String value) { this.value = value; }
    }

    /**
     * 返回records
     * @return
     */
    public List<Object> getRecordMap() throws Exception {
        Chrom chrom = new ChromImpl();
        Pos pos = new PosImpl();
        Id id = new IdImpl();
        Ref ref = new refImpl();
        Alt alt = new AltImpl();
        //PTMs ptms = new PTMsImpl();
        Qual qual=new QualImpl();
        Filter filter = new FilterImpl();
        Info info = new InfoImpl();
        Format format = new FormatImpl();
        Samples samples = new SamplesImpl();

        Map<Integer,Object> mapChrom = chrom.getChromFromUser();
        Map<Integer,Object> mapPos = pos.getPosFormUser();
        Map<Integer,Object> mapId = id.getIdFormUser();
        Map<Integer,Object> mapRef = ref.getRefFromUser();
        Map<Integer,Object> mapAlt = alt.getAltFromUser();
        //Map<Integer,Object> mapPTMs = ptms.getPTMsFromUser();
        Map<Integer,Object> mapQual = qual.getQualFromUser();
        Map<Integer,Object> mapFilter = filter.getFilterFromUser();
        Map<Integer,Object> mapInfo = info.getInfoFormUser();
        //处理INFO字段
        Map<Integer,String> processInfoMap = processInfo(mapInfo);

        Map<Integer,Object> mapFormat = format.getFormatFromUser();

        Map<Integer,Object> mapSamples = samples.getSampleFromUser();
        //处理sample字段
        Map<Integer,String> processSampleMap = processSample(mapSamples);
        //System.out.println("ssss:"+processSampleMap);
        Set<Integer> keySet = mapChrom.keySet();

        List<Object> list1 = new ArrayList<Object>();
        for(Integer ks:keySet){
            List<String> list2 = new ArrayList<String>();

            Map<String,String> mapName1 = (Map<String, String>) mapChrom.get(ks);
            Map<String,String> mapPos1 = (Map<String, String>) mapPos.get(ks);
            Map<String,String> mapId1 = (Map<String, String>) mapId.get(ks);
            Map<String,String> mapRef1 = (Map<String, String>) mapRef.get(ks);
            Map<String,String> mapAlt1 = (Map<String, String>) mapAlt.get(ks);
            //Map<String,String> mapPTMs1 = (Map<String, String>) mapPTMs.get(ks);
            Map<String,String> mapQual1 = (Map<String, String>) mapQual.get(ks);
            Map<String,String> mapFilter1 = (Map<String, String>) mapFilter.get(ks);

            Map<String,String> mapFormat1 = (Map<String, String>) mapFormat.get(ks);

            //System.out.println(mapName1.get("name")+"\t"+mapPos1.get("pos")+"\t"+mapId1.get("id")+"\t"+mapRef1.get("ref")+"\t"+mapAlt1.get("alt")+"\t"+mapQual1.get("qual")+"\t"+mapFilter1.get("filter"));
            list2.add(mapName1.get("name")+"\t"+mapPos1.get("pos")+"\t"+mapId1.get("id")+"\t"+mapRef1.get("ref")+"\t"+mapAlt1.get("alt")+"\t"+mapQual1.get("qual")+"\t"+mapFilter1.get("filter")+"\t"+processInfoMap.get(ks)+"\t"+mapFormat1.get("format")+"\t"/*+processSampleMap.get(ks)*/);
            list1.add(list2);
        }
        //System.out.println("recordsMap1-76:"+list1);
        return list1;
    }

    /**
     * 返回records 的列名哪一行
     * @return
     */
    public List<Object> getRecordTitleMap(){
        recordTitleEnum chromEnum = recordTitleEnum.CHROM;
        List<Object> list1 = new ArrayList<Object>();
        List<String> list2 = new ArrayList<String>();

        String tempSamples="";
        //System.out.println("recordsMap1-90:"+Samples);
        for(String sampleTitle:Samples){
            String temp=sampleTitle;
            tempSamples=tempSamples+"\t"+temp;
        }
        //System.out.println(tempSamples);

        list2.add(recordTitleEnum.CHROM.getValue()+"\t"+recordTitleEnum.POS.getValue()+"\t"+recordTitleEnum.ID.getValue()
                +"\t"+recordTitleEnum.REF.getValue()+"\t"+recordTitleEnum.ALT.getValue()+"\t"/*+recordTitleEnum.PTMs.getValue()+"\t"*/+recordTitleEnum.QUAL.getValue()
                +"\t"+recordTitleEnum.FILTER.getValue()+"\t"+recordTitleEnum.INFO.getValue()+"\t"+recordTitleEnum.FORMAT.getValue()+tempSamples);
        list1.add(list2);
        return list1;
    }

    /**
     * 辅助函数 将INFO处理成统一格式
     * @param map
     * @return
     */
    public Map<Integer, String> processInfo(Map<Integer,Object> map){
        Set<Integer> keySet = map.keySet();
        MapToStr mapToStr = new MapToStr();
        Map<Integer,String> map1 = new HashMap<Integer, String>();
        for(Integer k:keySet){
            Map<String,String> mapV = (Map<String, String>) map.get(k);
            String textV = mapToStr.getMapToString(mapV);
            //System.out.println(textV);
            map1.put(k,textV);
        }
        //System.out.println(map1);
        return map1;
    }

    /**
     * 辅助函数 将sample处理成统一格式
     * @param map
     * @return
     */
    public Map<Integer, String> processSample(Map<Integer,Object> map){
        Set<Integer> keySet = map.keySet();
        MapToStr mapToStr = new MapToStr();
        Map<Integer,String> map1 = new HashMap<Integer, String>();
        for(Integer ks:keySet){
            Map<String,Object> mapO = (Map<String, Object>) map.get(ks);
            //System.out.println("uuu"+mapO);
            List<String> listValue = (List<String>) mapO.get("value");
            List<String> listSample = (List<String>) mapO.get("sample");
            String ss = String.join("\t",listValue);
            //System.out.println(ss);
            map1.put(ks,ss);
            //获得Samples的列名
            Samples= listSample.toArray(new String[0]);
        }
        return map1;
    }


}
