package meta.format;

public enum PresetFormat {
    GT("1","String","Genotype"),
    GQ("1","Integer","Genotype Quality"),
    DP("1","Integer","Read Depth"),
    HQ("2","Integer","Haplotype Quality");
    private String number="";
    private String type="";
    private String description="";
    PresetFormat(String number,String type,String description) {
        this.number=number;
        this.type=type;
        this.description=description;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
