package meta.format;

import meta.info.PresetINFO;
import meta.info.SelfDefinedINFO;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class Format {
    public List<Object> getFormat() {
        Set<String> formatSet = new LinkedHashSet<>();
        //模拟records中使用的INFO
        formatSet.add("GT");
        formatSet.add("GQ");
        formatSet.add("DP");
        formatSet.add("HQ");

        List<String> list1 = new ArrayList<>();
        List<Object> list = new ArrayList<>();

        //预设的INFO
        for (String str : formatSet) {
            PresetFormat tempFormat = PresetFormat.valueOf(str);
            list1.add("##FORMAT=<ID=" + str + ",Number=" + tempFormat.getNumber() + ",Type=" + tempFormat.getType() + ",Description=\"" + tempFormat.getDescription() + "\">");
        }
        list.add(list1);
        return list;
    }
}
