package meta.info;

import java.util.*;

public class Info {
    public List<Object> getINFO(){

        return null;
    }

    public List<Object> getINFOTest(){
        boolean flag = false;
        SelfDefinedINFO selfDefinedINFO = new SelfDefinedINFO();
        SelfDefinedINFO selfDefinedINFO1 = new SelfDefinedINFO();
        Set<SelfDefinedINFO> selfDefinedInfoSet = new LinkedHashSet<>();
        Set<String> infoSet = new LinkedHashSet<>();
        //模拟records中使用的INFO
        infoSet.add("NS");
        infoSet.add("DP");
        infoSet.add("AF");
        infoSet.add("AA");

        List<String> list1 = new ArrayList<>();
        List<Object> list = new ArrayList<>();

        //预设的INFO
        for(String str:infoSet){
            //System.out.println(str);
            PresetINFO tempInfo = PresetINFO.valueOf(str);
            //System.out.println(tempInfo.getDescription());
            list1.add("##INFO=<ID="+str+",Number="+tempInfo.getNumber()+",Type="+tempInfo.getType()+",Description=\""+tempInfo.getDescription()+"\">");
        }
        //用于用户自定义的INFO
        if(flag==true){
            //模拟用户产生INFO
            selfDefinedINFO.setId("TEST");
            selfDefinedINFO.setNumber("1");
            selfDefinedINFO.setType("Integer");
            selfDefinedINFO.setDescription("A test");
            selfDefinedINFO1.setId("TEST1");
            selfDefinedINFO1.setNumber("1");
            selfDefinedINFO1.setType("Integer");
            selfDefinedINFO1.setDescription("A test1");

            selfDefinedInfoSet.add(selfDefinedINFO);
            selfDefinedInfoSet.add(selfDefinedINFO1);
            Iterator<SelfDefinedINFO> infoIterator = selfDefinedInfoSet.iterator();
            while(infoIterator.hasNext()){
                SelfDefinedINFO selfDefinedINFO2= infoIterator.next();
                //System.out.println(selfDefinedINFO1.getDescription());
                list1.add("##INFO=<ID="+selfDefinedINFO2.getId()+",Number="+selfDefinedINFO2.getNumber()+",Type="+selfDefinedINFO2.getType()+",Description=\""+selfDefinedINFO2.getDescription()+"\">");
            }
        }
        list.add(list1);
        return list;
    }
}
