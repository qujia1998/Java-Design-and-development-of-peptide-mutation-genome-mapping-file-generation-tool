package meta.info;

public enum PresetINFO {
        NS("1","Integer","Number of Samples With Data"),
        DP("1","Integer","Total Depth"),
        AF("A","Float","Allele Frequency"),
        AA("1","String","Ancestral Allele");
        private String number="";
        private String type="";
        private String description="";
        PresetINFO(String number,String type,String description) {
            this.number=number;
            this.type=type;
            this.description=description;
        }

        public String getNumber() {
            return number;
        }

        public void setNumber(String number) {
            this.number = number;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

}
