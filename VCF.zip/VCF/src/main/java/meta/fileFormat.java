package meta;

import java.util.ArrayList;
import java.util.List;

public class fileFormat {
    enum metaEnum{
        FILEFORMAT("fileformat"),FILEDATE("fileDate"),SOURCE("source"),PHASING("phasing"),REFERENCE("reference");
        private  String value;
        metaEnum(String value) {
            this.value = value;
        }

        public String getValue() {
            return value;
        }

        public void setValue(String value) {
            this.value = value;
        }
    }
    public List<Object> getFileFormat(){
        String fileFormat = "VCFv4.2";
        String fileDate = "20090805";
        String source = "myImputationProgramV3.1";
        String reference = "file:///seq/references/1000GenomesPilot-NCBI36.fasta";
        String phasing="partial";
        List<String> list = new ArrayList<>();
        List<Object> list1 = new ArrayList<>();
        list.add("##"+metaEnum.FILEFORMAT.getValue()+"="+fileFormat);
        list.add("##"+metaEnum.FILEDATE.getValue()+"="+fileDate);
        list.add("##"+metaEnum.SOURCE.getValue()+"="+source);
        list.add("##"+metaEnum.REFERENCE.getValue()+"="+reference);
        list.add("##"+metaEnum.PHASING.getValue()+"="+phasing);
        list1.add(list);
        return list1;
    }
}
