package meta.filter;

import meta.info.PresetINFO;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class Filter {
    public List<Object> getFilter(){
        Set<String> filterSet = new LinkedHashSet<>();
        //模拟records中使用的INFO
        filterSet.add("Q10");
        filterSet.add("S50");

        List<String> list1 = new ArrayList<>();
        List<Object> list = new ArrayList<>();

        //预设的INFO
        for(String str:filterSet){
            PresetFilter tempFilter = PresetFilter.valueOf(str);
            list1.add("##FILTER=<ID="+tempFilter.getId()+",Description=\""+tempFilter.getDescription()+"\">");
        }
        list.add(list1);

        return list;
    }
}
